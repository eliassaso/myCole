<?php $__env->startSection('content'); ?>
<div style='margin-top: 10px;' class="container-fluid" id = 'main'>
<div class="col-md-4 col-md-offset-4">

        <div class="container-fluid panel panel-default" id="">
        <?php echo Form::open(['method'=>'POST', 'action' => ['FrontController@includeNewToken']]); ?>

            <div class="form-group">
                <?php echo Form::hidden('idTema', $id, ['class'=>'form-control']); ?>

            </div>
            <div class="col s6">
                <?php echo Form::label('licencia','Digite su licencia'); ?>

                <?php echo Form::text('licencia', null , ['class'=>'col s6']); ?>

            </div>

            <!-- Submit -->
            <button class = 'waves-effect waves-light btn left hoverable' type = "submit">
                <?php echo Form::submit('Enviar', ['class' => '']); ?>

            </button>

        <?php echo Form::close(); ?>


        <br><br>
        <span class = "red-text darken-1"><?php echo $mensaje; ?></span>

        </div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>