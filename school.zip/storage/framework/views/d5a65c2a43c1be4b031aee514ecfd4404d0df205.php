<body>
<!--nav-->
<nav class="navbar navbar-custom navbar-fixed-top" role="">
    <div class="container">
        <div class="nav-wrapper">
            <a href="/home" class="brand-logo">SCHOOL</a>
            <div class="navbar-header page-scroll">

            </div>
            <a class="navbar-brand" href="#"></a>


        <!--<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">-->
            <ul class="right hide-on-med-and-down">
                <!--<li><a href="<?php echo e(url('/')); ?>">Home</a></li>-->
                <?php if(!Auth::guest() && Auth::user()->roll == 'estudiante'): ?>

                    <ul id="dropdown6" class="dropdown-content" role="menu">

                                    <!--<li><a href="/front/1" id='1' onclick="getTemas(id)">1</a></li>-->
                                    <li><a id='' href="<?php echo e(url('/front/1')); ?>">1</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/2')); ?>">2</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/3')); ?>">3</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/4')); ?>">4</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/5')); ?>">5</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/6')); ?>">6</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/7')); ?>">7</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/8')); ?>">8</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/9')); ?>">9</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/10')); ?>">10</a></li>
                                    <li><a id='' href="<?php echo e(url('/front/11')); ?>">11</a></li>

                    </ul>

                <li><a class="dropdown-button" href="#!" data-activates="dropdown6">Materias<i class="material-icons right">arrow_drop_down</i></a>

                <?php endif; ?>
                <?php if(!Auth::guest() && Auth::user()->roll == 'profesor'): ?>
                    <li><a href="<?php echo e(url('/dashboard')); ?>">Temas</a></li>
                    <!--<li><a href="<?php echo e(url('/profesores')); ?>"></a></li>-->
                <?php endif; ?>
                <?php if(!Auth::guest() && Auth::user()->roll == 'admin'): ?>
                    <li><a href="<?php echo e(url('/materias')); ?>">Materias</a></li>
                    <ul id="dropdown4" class="dropdown-content" role="menu">

                                    <!--<li><a href="/front/1" id='1' onclick="getTemas(id)">1</a></li>-->
                                    <li><a href="<?php echo e(url('/profesores')); ?>">Profesores</a></li>
                                    <li><a href="<?php echo e(url('/profesores/create')); ?>">Reclutar</a></li>
                    </ul>

                   <li><a class="dropdown-button" href="#!" data-activates="dropdown4">Profesores<i class="material-icons right">arrow_drop_down</i></a>
                <?php endif; ?>
            <!--</ul>








            <ul class="nav navbar-nav navbar-right">-->
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Entrar</a></li>
                    <li><a href="<?php echo e(url('/register')); ?>">Registrar</a></li>
                <?php else: ?>
                <ul id="dropdown1" class="dropdown-content">
                    <li>
                        <a href="<?php echo e(url('/logout')); ?>"
                           onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                            Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>

                  <li><a href="<?php echo e(url('/user')); ?>">Perfil</a></li>
                  <!--<li><a href="#!">two</a></li>
                  <li class="divider"></li>
                  <li><a href="#!">three</a></li>-->
                </ul>

                <li><a class="dropdown-button" href="#!" data-activates="dropdown1"><?php echo e(Auth::user()->name); ?> <i class="material-icons right">arrow_drop_down</i></a>
                </li>
                <?php endif; ?>
            </ul>

            <ul id="nav-mobile" class="side-nav">
                <?php if(!Auth::guest() && Auth::user()->roll == 'estudiante'): ?>

                <ul id="dropdown3" class="dropdown-content" role="menu">

                                    <!--<li><a href="/front/1" id='1' onclick="getTemas(id)">1</a></li>-->
                                    <li><a id='1' onclick="getTemas(id)">1</a></li>
                                    <li><a id='2' onclick="getTemas(id)">2</a></li>
                                    <li><a id='3' onclick="getTemas(id)">3</a></li>
                                    <li><a id='4' onclick="getTemas(id)">4</a></li>
                                    <li><a id='5' onclick="getTemas(id)">5</a></li>
                                    <li><a id='6' onclick="getTemas(id)">6</a></li>
                                    <li><a id='7' onclick="getTemas(id)">7</a></li>
                                    <li><a id='8' onclick="getTemas(id)">8</a></li>
                                    <li><a id='9' onclick="getTemas(id)">9</a></li>
                                    <li><a id='10' onclick="getTemas(id)">10</a></li>
                                    <li><a id='11' onclick="getTemas(id)">11</a></li>


                </ul>
                <li><a class="dropdown-button" href="#!" data-activates="dropdown3">Materias<i class="material-icons right">arrow_drop_down</i></a>

                <?php endif; ?>
                <?php if(!Auth::guest() && Auth::user()->roll == 'profesor'): ?>
                    <li><a href="<?php echo e(url('/dashboard')); ?>">Temas</a></li>
                    <!--<li><a href="<?php echo e(url('/profesores')); ?>"></a></li>-->
                <?php endif; ?>
                <?php if(!Auth::guest() && Auth::user()->roll == 'admin'): ?>
                    <ul id="dropdown5" class="dropdown-content" role="menu">

                                    <!--<li><a href="/front/1" id='1' onclick="getTemas(id)">1</a></li>-->
                                    <li><a href="<?php echo e(url('/profesores')); ?>">Profesores</a></li>
                                    <li><a href="<?php echo e(url('/profesores/create')); ?>">Reclutar</a></li>
                    </ul>

                   <li><a class="dropdown-button" href="#!" data-activates="dropdown5">Profesores<i class="material-icons right">arrow_drop_down</i></a>
                   <li><a href="<?php echo e(url('/materias')); ?>">Materias</a></li>
                <?php endif; ?>
            <!--</ul>

            <ul class="nav navbar-nav navbar-right">-->
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Entrar</a></li>
                    <li><a href="<?php echo e(url('/register')); ?>">Registrar</a></li>
                <?php else: ?>
                <ul id="dropdown2" class="dropdown-content">
                    <li>
                        <a href="<?php echo e(url('/logout')); ?>"
                           onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                            Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                  <!--<li><a href="#!">two</a></li>
                  <li class="divider"></li>
                  <li><a href="#!">three</a></li>-->
                </ul>

                <li><a class="dropdown-button" href="#!" data-activates="dropdown2"><?php echo e(Auth::user()->name); ?> <i class="material-icons right">arrow_drop_down</i></a>
                </li>
                <?php endif; ?>
            </ul>

            <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>

        </div>
    </div>
</nav>
<!--end nav-->
