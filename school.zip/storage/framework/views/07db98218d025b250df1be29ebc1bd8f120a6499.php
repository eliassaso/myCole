<?php $__env->startSection('content'); ?>
    <div class="container" id = 'main' style="margin-top: 5px;">
<?php $__currentLoopData = $materia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <nav>
        <div class="row">
          <div class="col s12">
            <a style="margin-left: 10px;" href="/home" class="breadcrumb">Principal</a>
            <a href="<?php echo e(url('/front/'.$mat->degree)); ?>" class="breadcrumb">Grado <?php echo $mat->degree; ?></a>
            <a href="<?php echo e(url('/titulos/'.$mat->id)); ?>" class="breadcrumb"><?php echo $mat->nombre_materia; ?></a>
            <a href="<?php echo e(url('/finalshow/'.$tema->id)); ?>" class="breadcrumb"><?php echo $tema->title; ?></a>
          </div>
        </div>
      </nav>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        <article>

            <h4 style="
            
              font-family: Roboto, sans-serif;
              font-size: 2.7em;
              font-weight: 100;
              line-height: 1em;
              letter-spacing: 0em;
              color: #3a9682;
              background-color: #fff;
              display: inline-block;

            "><?php echo e($tema->title); ?></h4><hr>

            <div class="body">
              <div class="form-group">
                <?php echo $tema->content; ?>

              </div>
            </div>
        </article>
        <br>
    
        <!--<table class="table table-striped">-->
            <tr>
                <h4 style="
            
              font-family: Roboto, sans-serif;
              font-size: 2.7em;
              font-weight: 100;
              line-height: 1em;
              letter-spacing: 0em;
              color: #3a9682;
              background-color: #fff;
              display: inline-block;

            ">Preguntas</h4><hr>
            </tr>
            
                <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <article>
                        <tr>
                        <td>
                <div class="col s12" style="border-bottom: 2px solid #c7c7c7;">

                    <h4><?php echo e($pregunta->pregunta); ?></h4>

                    <form name="formulario<?php echo e($pregunta->id); ?>" id="formulario<?php echo e($pregunta->id); ?>">
                      
                    
                    
                    <div class="btn-group row" data-toggle="buttons">
                    
                    <p>
                      <input class="with-gap" type="radio" name="options<?php echo e($pregunta->id); ?>" id="<?php echo e($pregunta->id); ?>_1" autocomplete="off">
                      <label for="<?php echo e($pregunta->id); ?>_1"><span style = "padding-left:5px; margin-right: 20px;">A </span></label>
                      <div class="col s12" style="padding-left: 20px; margin-left: 0px; margin-top: 5px;">
                          <?php echo e($pregunta->respuesta_1); ?>

                        </div><br>
                    </p>
                    
                    <p>
                      <input class="with-gap" type="radio" name="options<?php echo e($pregunta->id); ?>" id="<?php echo e($pregunta->id); ?>_2" autocomplete="off">
                      <label for="<?php echo e($pregunta->id); ?>_2"><span style = "padding-left:5px; margin-right: 20px;">B </span></label>
                      <div class="col s12" style="padding-left: 20px; margin-left: 0px; margin-top: 5px;">
                          <?php echo e($pregunta->respuesta_2); ?>

                        </div><br>
                    </p>
                    
                    <p>
                      <input class="with-gap" type="radio" name="options<?php echo e($pregunta->id); ?>" id="<?php echo e($pregunta->id); ?>_3" autocomplete="off">
                      <label for="<?php echo e($pregunta->id); ?>_3"><span style = "padding-left:5px; margin-right: 20px;">C </span></label>
                       <div class="col s12" style="padding-left: 20px; margin-left: 0px; margin-top: 5px;">
                          <?php echo e($pregunta->respuesta_3); ?>

                        </div><br>

                    </p>
                    
                    <p>
                      <input class="with-gap" type="radio" name="options<?php echo e($pregunta->id); ?>" id="<?php echo e($pregunta->id); ?>_4" autocomplete="off">
                      <label for="<?php echo e($pregunta->id); ?>_4"><span style = "padding-left:5px; margin-right: 20px;">D </span></label>
                      <div class="col s12" style="padding-left: 20px; margin-left: 0px; margin-top: 5px;">
                          <?php echo e($pregunta->respuesta_4); ?>

                        </div><br>
                    </p>

              
                           

                        <button type="button" id="<?php echo e($pregunta->id); ?>" value="<?php echo e($pregunta->respuesta); ?>" class="waves-effect waves-light btn" onclick="respuestaCorrecta(this)">Aceptar</button>
                    
                    </div>
                    <div id="noty-holder<?php echo e($pregunta->id); ?>">  
                    </div>
                  </form>
  
                  </div>
                            <input type="hidden" id="notificacion<?php echo e($pregunta->id); ?>" value ="<?php echo e($pregunta->notificacion); ?>"></input>
                            <input type="hidden" id="correcta<?php echo e($pregunta->id); ?>" value="<?php echo e($pregunta->respuesta); ?>"></input>
                            <input type="hidden" id="link<?php echo e($pregunta->id); ?>" value="<?php echo e($pregunta->link); ?>"></input>
                 
                        </td>
                        </tr>
                    </article>
  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <!--</table>-->


        <br><!--<div id="player" class="video-container"></div>-->
         <div class="video-container">
        <iframe width="853" height="480" src="//www.youtube.com/embed/<?php echo e($tema->link); ?>?rel=0" frameborder="0" allowfullscreen></iframe>
      </div>
       
      <?php echo $__env->make('front.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
   
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>