<?php $__env->startSection('content'); ?>
    <div class="container-fluid panel panel-default">
    <h1>Editando: <?php echo $pregunta->pregunta; ?></h1>
    <hr>

    <?php echo Form::model($pregunta, ['method'=>'PATCH', 'action' => ['PreguntasController@update', $pregunta->id]]); ?>

        <?php echo $__env->make('preguntas.form',['submitButtonText'=>'Actualizar pregunta'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>


    <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>