<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <?php echo Html::style('/css/materialize.css'); ?>

    <?php echo Html::style('/css/style.css'); ?>

 

    <!-- Fonts -->
    <!--<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>-->

</head>
<body>
    <!-- Navbar -->
    <?php echo $__env->make('partials.laravelnavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <div class="footer">
        <?php echo $__env->yieldContent('footer'); ?>
        <!-- Scripts -->
        <?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

        <?php echo Html::script('/js/materialize.min.js'); ?>

        <?php echo Html::script('/js/init.js'); ?>

        <?php echo Html::script('/js/main.js'); ?>



        <script src="<?php echo e(asset('/vendors/ckeditor/ckeditor.js')); ?>"></script>
        <?php echo $__env->yieldContent('js'); ?>
    </div>

</body>
</html>
