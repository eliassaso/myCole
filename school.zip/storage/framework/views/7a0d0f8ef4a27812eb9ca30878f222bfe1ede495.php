<?php $__env->startSection('content'); ?>
    <div class="container-fluid panel panel-default">
    <h1>Crear pregunta</h1>
    <hr>

    <?php echo Form::open(['url' => 'preguntas']); ?>

        <?php echo $__env->make('preguntas.form',['submitButtonText'=>'Agregar pregunta'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>


    <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>